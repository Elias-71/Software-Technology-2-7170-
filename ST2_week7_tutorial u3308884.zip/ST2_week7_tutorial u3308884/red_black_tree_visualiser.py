import tkinter as tk

RED = "RED"
BLACK = "BLACK"

class RBNode:
    def __init__(self, key):
        self.key = key
        self.color = RED
        self.left = None
        self.right = None
        self.parent = None


class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(None)
        self.NIL.color = BLACK
        self.root = self.NIL

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def right_rotate(self, y):
        x = y.left
        y.left = x.right
        if x.right != self.NIL:
            x.right.parent = y
        x.parent = y.parent
        if y.parent is None:
            self.root = x
        elif y == y.parent.right:
            y.parent.right = x
        else:
            y.parent.left = x
        x.right = y
        y.parent = x

    def insert(self, key):
        node = RBNode(key)
        node.left = self.NIL
        node.right = self.NIL
        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if key < current.key:
                current = current.left
            else:
                current = current.right

        node.parent = parent

        if parent is None:
            self.root = node
        elif key < parent.key:
            parent.left = node
        else:
            parent.right = node

        self.fix_insert(node)

    def fix_insert(self, k):
        while k.parent and k.parent.color == RED:
            if k.parent == k.parent.parent.left:
                u = k.parent.parent.right
                if u.color == RED:
                    k.parent.color = BLACK
                    u.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.right_rotate(k.parent.parent)
            else:
                u = k.parent.parent.left
                if u.color == RED:
                    k.parent.color = BLACK
                    u.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.left_rotate(k.parent.parent)
            if k == self.root:
                break
        self.root.color = BLACK


class RBTreeVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Red-Black Tree Visualizer")

        self.tree = RedBlackTree()

        top = tk.Frame(root)
        top.pack(pady=10)

        tk.Label(top, text="Value:").pack(side=tk.LEFT)
        self.entry = tk.Entry(top, width=10)
        self.entry.pack(side=tk.LEFT)

        tk.Button(top, text="Insert", command=self.insert_value).pack(side=tk.LEFT, padx=5)

        self.canvas = tk.Canvas(root, width=800, height=400, bg="white")
        self.canvas.pack(pady=10)

    def insert_value(self):
        try:
            value = int(self.entry.get())
        except ValueError:
            return
        self.tree.insert(value)
        self.entry.delete(0, tk.END)
        self.draw_tree()

    def draw_tree(self):
        self.canvas.delete("all")
        if self.tree.root != self.tree.NIL:
            self._draw_node(self.tree.root, 400, 40, 180)

    def _draw_node(self, node, x, y, offset):
        if node == self.tree.NIL:
            return

        if node.left != self.tree.NIL:
            self.canvas.create_line(x, y, x - offset, y + 70)
            self._draw_node(node.left, x - offset, y + 70, offset // 2)

        if node.right != self.tree.NIL:
            self.canvas.create_line(x, y, x + offset, y + 70)
            self._draw_node(node.right, x + offset, y + 70, offset // 2)

        fill = "red" if node.color == RED else "black"
        text_color = "white" if node.color == BLACK else "black"

        self.canvas.create_oval(x - 20, y - 20, x + 20, y + 20, fill=fill)
        self.canvas.create_text(x, y, text=str(node.key), fill=text_color)


if __name__ == "__main__":
    root = tk.Tk()
    app = RBTreeVisualizer(root)
    root.mainloop()