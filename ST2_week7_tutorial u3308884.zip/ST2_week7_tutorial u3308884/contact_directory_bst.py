class Contact:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None

class ContactDirectory:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Contact(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            # Update phone if contact already exists
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

    def inorder(self, root):
        if root:
            self.inorder(root.left)
            print(f"Name: {root.name}, Phone: {root.phone}")
            self.inorder(root.right)

# Testing the binary search tree
directory = ContactDirectory()
directory.root = directory.insert(directory.root, 'Alice', '123-456-7890')
directory.root = directory.insert(directory.root, 'Bob', '234-567-8901')
directory.root = directory.insert(directory.root, 'Eve', '345-678-9012')

print("All contacts:")
directory.inorder(directory.root)

print("\nSearching for Bob:")
contact = directory.search(directory.root, 'Bob')
if contact:
    print(f"Found contact: {contact.name} - {contact.phone}")
else:
    print("Contact not found")

print("\nDeleting Alice:")
directory.root = directory.delete(directory.root, 'Alice')
directory.inorder(directory.root)