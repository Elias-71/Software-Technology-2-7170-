class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

# Traversals
def preorder(root):
    if root:
        print(root.value, end=' ')
        preorder(root.left)
        preorder(root.right)

def inorder(root):
    if root:
        inorder(root.left)
        print(root.value, end=' ')
        inorder(root.right)

def postorder(root):
    if root:
        postorder(root.left)
        postorder(root.right)
        print(root.value, end=' ')

# Count nodes
def count_nodes(root):
    if root is None:
        return 0
    return 1 + count_nodes(root.left) + count_nodes(root.right)

# Height
def height(root):
    if root is None:
        return 0
    return 1 + max(height(root.left), height(root.right))

# Search
def search_bst(root, val):
    if root is None or root.value == val:
        return root
    if val < root.value:
        return search_bst(root.left, val)
    else:
        return search_bst(root.right, val)

# Insert
def insert_bst(root, val):
    if root is None:
        return Node(val)
    if val < root.value:
        root.left = insert_bst(root.left, val)
    else:
        root.right = insert_bst(root.right, val)
    return root

# Find min
def find_min(root):
    current = root
    while current.left:
        current = current.left
    return current

# Delete
def delete_node(root, val):
    if root is None:
        return root
    if val < root.value:
        root.left = delete_node(root.left, val)
    elif val > root.value:
        root.right = delete_node(root.right, val)
    else:
        if root.left is None:
            return root.right
        elif root.right is None:
            return root.left
        temp = find_min(root.right)
        root.value = temp.value
        root.right = delete_node(root.right, temp.value)
    return root

# Level order
from collections import deque
def level_order(root):
    if not root:
        return
    queue = deque([root])
    while queue:
        node = queue.popleft()
        print(node.value, end=' ')
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)

# ===== TEST =====

root = None
values = [10, 5, 15, 3, 7]

for v in values:
    root = insert_bst(root, v)

print("Inorder:")
inorder(root)

print("\nPreorder:")
preorder(root)

print("\nPostorder:")
postorder(root)

print("\nTotal nodes:", count_nodes(root))
print("Height:", height(root))

print("\nSearch 7:", "Found" if search_bst(root, 7) else "Not found")

root = delete_node(root, 5)
print("\nAfter deleting 5 (Inorder):")
inorder(root)

print("\nLevel order:")
level_order(root)