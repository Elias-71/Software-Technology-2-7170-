import tkinter as tk
import math

class KochSnowflake:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("Koch Snowflake")

        self.width = 600
        self.height = 600

        self.canvas = tk.Canvas(self.window, width=self.width, height=self.height, bg="white")
        self.canvas.pack()

        frame = tk.Frame(self.window)
        frame.pack()

        tk.Label(frame, text="Enter an order: ").pack(side=tk.LEFT)
        self.order = tk.StringVar()
        tk.Entry(frame, textvariable=self.order, justify=tk.RIGHT, width=5).pack(side=tk.LEFT)
        tk.Button(frame, text="Display Koch Snowflake", command=self.display).pack(side=tk.LEFT)

        self.window.mainloop()

    def display(self):
        self.canvas.delete("all")
        order = int(self.order.get())

        size = 300
        h = math.sqrt(3) / 2 * size

        p1 = (150, 400)
        p2 = (450, 400)
        p3 = (300, 400 - h)

        self.draw_koch(order, p1, p2)
        self.draw_koch(order, p2, p3)
        self.draw_koch(order, p3, p1)

    def draw_koch(self, order, p1, p5):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p5[0], p5[1])
        else:
            x1, y1 = p1
            x5, y5 = p5

            dx = (x5 - x1) / 3
            dy = (y5 - y1) / 3

            p2 = (x1 + dx, y1 + dy)
            p4 = (x1 + 2 * dx, y1 + 2 * dy)

            angle = math.radians(60)
            px = p2[0] + (dx * math.cos(angle) - dy * math.sin(angle))
            py = p2[1] + (dx * math.sin(angle) + dy * math.cos(angle))
            p3 = (px, py)

            self.draw_koch(order - 1, p1, p2)
            self.draw_koch(order - 1, p2, p3)
            self.draw_koch(order - 1, p3, p4)
            self.draw_koch(order - 1, p4, p5)

KochSnowflake()