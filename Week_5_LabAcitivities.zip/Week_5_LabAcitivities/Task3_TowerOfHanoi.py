moves = 0

def main():
    global moves
    n = eval(input("Enter number of disks: "))

    # Reset moves each time the program runs
    moves = 0

    # Find the solution recursively
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    print("Number of moves is", moves)

# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower
def moveDisks(n, fromTower, toTower, auxTower):
    global moves

    if n == 1:  # Stopping condition
       # print("Move disk", n, "from", fromTower, "to", toTower)
        moves += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
       # print("Move disk", n, "from", fromTower, "to", toTower)
        moves += 1
        moveDisks(n - 1, auxTower, toTower, fromTower)

main()  # Call the main function